"""
Starknet Mini-Pay Core Module
Simple P2P payments on Starknet using starknet-py
"""

import asyncio
import hashlib
import json
from typing import Optional, Dict, Any
from dataclasses import dataclass
from enum import Enum

from starknet_py.net.full_node_client import FullNodeClient
from starknet_py.net.account.account import Account
from starknet_py.net.signer.key_pair import KeyPair
from starknet_py.contract import Contract
from starknet_py.transactions.invoke import InvokeFunction
from starknet_py.constants import ETH_TOKEN_ADDRESS, STRK_TOKEN_ADDRESS


class Token(Enum):
    ETH = "ETH"
    STRK = "STRK"
    USDC = "USDC"


# USDC contract address on Starknet mainnet
USDC_ADDRESS = 0x053c91253bc9682c04929ca02ed00b3e423f6714d2ea42d73d1b8f3f8d400005

# ETH contract address on Starknet mainnet
ETH_ADDRESS = 0x049d36570d4e46f48e99674bd3fcc84644ddd6b96f7c741b1562b82dc9dd0cc


@dataclass
class PaymentResult:
    tx_hash: str
    status: str
    block_number: Optional[int] = None
    error: Optional[str] = None


class MiniPay:
    """Core Mini-Pay class for Starknet payments"""
    
    def __init__(self, rpc_url: str = "https://rpc.starknet.lava.build:443"):
        self.rpc_url = rpc_url
        self.client = FullNodeClient(node_url=rpc_url)
        
        # Token addresses
        self.tokens = {
            "ETH": ETH_ADDRESS,
            "STRK": STRK_TOKEN_ADDRESS,
            "USDC": USDC_ADDRESS,
        }
    
    def _get_token_decimals(self, token: str) -> int:
        """Get decimal places for token"""
        decimals = {
            "ETH": 18,
            "STRK": 18,
            "USDC": 6,
        }
        return decimals.get(token.upper(), 18)
    
    def _create_account(self, address: str, private_key: str) -> Account:
        """Create Account instance from address and private key"""
        key_pair = KeyPair.from_private_key(int(private_key, 16))
        return Account(
            address=int(address, 16),
            client=self.client,
            key_pair=key_pair,
        )
    
    async def get_balance(self, address: str, token: str = "ETH") -> int:
        """Get token balance for an address"""
        token_symbol = token.upper()
        token_address = self.tokens.get(token_symbol)
        
        if not token_address:
            raise ValueError(f"Unknown token: {token}")
        
        # For ETH, use get_balance
        if token_symbol == "ETH":
            balance = await self.client.get_balance(int(address, 16))
            return balance
        
        # For ERC20 tokens, call balanceOf
        erc20_abi = [
            {
                "name": "balanceOf",
                "type": "function",
                "inputs": [{"name": "account", "type": "felt"}],
                "outputs": [{"name": "balance", "type": "Uint256"}],
                "stateMutability": "view"
            }
        ]
        
        contract = Contract(
            address=token_address,
            abi=erc20_abi,
            client=self.client
        )
        
        result = await contract.functions["balanceOf"].call(int(address, 16))
        return result.balance  # Uint256 returns .balance attribute
    
    async def send(
        self,
        from_address: str,
        private_key: str,
        to_address: str,
        amount_wei: int,
        token: str = "ETH",
        memo: Optional[str] = None
    ) -> str:
        """
        Send a payment
        
        Args:
            from_address: Sender's Starknet address
            private_key: Sender's private key (hex)
            to_address: Recipient's Starknet address
            amount_wei: Amount in wei (10**18 for ETH)
            token: Token symbol (ETH, STRK, USDC)
            memo: Optional memo/note
        
        Returns:
            Transaction hash
        """
        token_symbol = token.upper()
        
        # Create account
        account = self._create_account(from_address, private_key)
        
        if token_symbol == "ETH":
            # Native ETH transfer using Account.execute
            # Note: This is a simplified version; for production, 
            # you might want to use the transfer function
            
            # Build transfer call
            calls = [
                {
                    "to": int(to_address, 16),
                    "value": amount_wei,
                    "data": "0x"
                }
            ]
            
            tx_hash = await account.execute(calls, max_fee=int(amount_wei * 0.01))
            
        else:
            # ERC20 transfer
            token_address = self.tokens.get(token_symbol)
            if not token_address:
                raise ValueError(f"Unknown token: {token_symbol}")
            
            erc20_abi = [
                {
                    "name": "transfer",
                    "type": "function",
                    "inputs": [
                        {"name": "to", "type": "felt"},
                        {"name": "amount", "type": "Uint256"}
                    ],
                    "outputs": [{"name": "success", "type": "felt"}],
                    "stateMutability": "external"
                }
            ]
            
            contract = Contract(
                address=token_address,
                abi=erc20_abi,
                client=self.client
            )
            
            # Call transfer function
            calls = [
                contract.functions["transfer"].prepare(
                    to=int(to_address, 16),
                    amount=amount_wei
                )
            ]
            
            tx_hash = await account.execute(calls, max_fee=int(amount_wei * 0.01))
        
        return hex(tx_hash)
    
    async def wait_for_confirmation(
        self,
        tx_hash: str,
        max_wait_seconds: int = 120,
        poll_interval: float = 2.0
    ) -> str:
        """Wait for transaction to be confirmed"""
        start_time = asyncio.get_event_loop().time()
        
        while True:
            elapsed = asyncio.get_event_loop().time() - start_time
            if elapsed > max_wait_seconds:
                return "TIMEOUT"
            
            status = await self.get_transaction_status(tx_hash)
            
            if status in ["CONFIRMED", "REJECTED", "FAILED"]:
                return status
            
            await asyncio.sleep(poll_interval)
    
    async def get_transaction_status(self, tx_hash: str) -> str:
        """Get transaction status"""
        try:
            receipt = await self.client.get_transaction_receipt(tx_hash)
            
            if hasattr(receipt, 'status'):
                status = str(receipt.status).upper()
                
                if 'ACCEPTED' in status:
                    return "CONFIRMED"
                elif 'PENDING' in status:
                    return "PENDING"
                elif 'REJECTED' in status:
                    return "REJECTED"
                elif 'FAILED' in status:
                    return "FAILED"
            
            return "UNKNOWN"
            
        except Exception as e:
            if "not found" in str(e).lower():
                return "NOT_FOUND"
            return f"ERROR: {e}"
    
    async def get_transaction(self, tx_hash: str) -> Dict[str, Any]:
        """Get full transaction details"""
        tx = await self.client.get_transaction(tx_hash)
        return {
            "hash": tx.hash,
            "status": str(tx.status),
            "block_number": tx.block_number if hasattr(tx, 'block_number') else None,
            "sender_address": str(tx.sender_address) if hasattr(tx, 'sender_address') else None,
            "nonce": tx.nonce if hasattr(tx, 'nonce') else None,
            "max_fee": tx.max_fee if hasattr(tx, 'max_fee') else None,
            "version": tx.version if hasattr(tx, 'version') else None,
        }
    
    async def get_block_number(self) -> int:
        """Get current block number"""
        return await self.client.get_block_number()


async def estimate_fee(
    rpc_url: str,
    from_address: str,
    to_address: str,
    amount_wei: int,
    token: str = "ETH"
) -> Dict[str, int]:
    """Estimate transaction fee"""
    client = FullNodeClient(node_url=rpc_url)
    
    account = Account(
        address=int(from_address, 16),
        client=client,
        key_pair=KeyPair.from_private_key(0),  # Dummy key for estimation
    )
    
    if token.upper() == "ETH":
        calls = [{
            "to": int(to_address, 16),
            "value": amount_wei,
            "data": "0x"
        }]
    else:
        token_address = ETH_ADDRESS  # Simplified
        calls = [
            {
                "to": token_address,
                "value": 0,
                "data": hex(int.from_bytes(b'transfer'[::-1], 'big'))[2:].zfill(64) + \
                        to_address[2:].zfill(64) + \
                        hex(amount_wei)[2:].zfill(64)
            }
        ]
    
    estimate = await account.estimate_fee(calls)
    return {
        "gas_price": estimate.gas_price,
        "gas_consumed": estimate.gas_consumed,
        "total_fee": estimate.total_fee,
    }


# Example usage
async def example():
    """Example payment flow"""
    RPC = "https://rpc.starknet.lava.build:443"
    
    pay = MiniPay(RPC)
    
    # Check balance
    balance = await pay.get_balance("0x053c91253bc9682c04929ca02ed00b3e423f6714d2ea42d73d1b8f3f8d400005", "ETH")
    print(f"ETH Balance: {balance / 10**18}")
    
    # Send payment (commented out for safety)
    # tx_hash = await pay.send(
    #     from_address="0x...",
    #     private_key="0x...",
    #     to_address="0x...",
    #     amount_wei=0.01 * 10**18,
    #     token="ETH",
    #     memo="Coffee payment"
    # )
    # print(f"Transaction: {tx_hash}")


if __name__ == "__main__":
    asyncio.run(example())
