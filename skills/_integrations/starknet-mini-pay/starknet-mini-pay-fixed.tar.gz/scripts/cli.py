#!/usr/bin/env python3.12
"""
Starknet Mini-Pay CLI
Simple P2P payments on Starknet

Usage:
    python3.12 scripts/cli.py send <address> <amount> [--memo MEMO]
    python3.12 scripts/cli.py qr <address> [--output FILE]
    python3.12 scripts/cli.py link <address> [--amount AMOUNT] [--memo MEMO]
    python3.12 scripts/cli.py invoice <address> <amount> [--expires SECONDS]
    python3.12 scripts/cli.py status <tx_hash>
    python3.12 scripts/cli.py balance <address>
    python3.12 scripts/cli.py parse-link <url>
"""

import argparse
import asyncio
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mini_pay import MiniPay
from qr_generator import QRGenerator
from link_builder import PaymentLink
from invoice import InvoiceManager


async def main():
    parser = argparse.ArgumentParser(description="Starknet Mini-Pay CLI")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Send command
    send_parser = subparsers.add_parser("send", help="Send a payment")
    send_parser.add_argument("address", help="Recipient Starknet address (0x...)")
    send_parser.add_argument("amount", type=float, help="Amount to send")
    send_parser.add_argument("--memo", help="Optional memo/note")
    send_parser.add_argument("--token", default="ETH", help="Token (ETH, STRK, USDC)")
    send_parser.add_argument("--from", dest="from_address", help="Sender address")
    send_parser.add_argument("--key", dest="private_key", help="Private key")
    
    # QR command
    qr_parser = subparsers.add_parser("qr", help="Generate QR code for address")
    qr_parser.add_argument("address", help="Starknet address")
    qr_parser.add_argument("--output", "-o", default="qr_code.png", help="Output file")
    qr_parser.add_argument("--amount", type=float, help="Pre-fill amount")
    qr_parser.add_argument("--memo", help="Pre-fill memo")
    
    # Link command
    link_parser = subparsers.add_parser("link", help="Create payment link")
    link_parser.add_argument("address", help="Recipient address")
    link_parser.add_argument("--amount", type=float, help="Amount")
    link_parser.add_argument("--memo", help="Payment memo")
    link_parser.add_argument("--token", default="ETH", help="Token")
    
    # Parse link command
    parse_parser = subparsers.add_parser("parse-link", help="Parse payment link")
    parse_parser.add_argument("url", help="Payment link URL")
    
    # Invoice command
    invoice_parser = subparsers.add_parser("invoice", help="Create payment invoice")
    invoice_parser.add_argument("address", help="Your address (to receive payment)")
    invoice_parser.add_argument("amount", type=float, help="Amount requested")
    invoice_parser.add_argument("--token", default="USDC", help="Token")
    invoice_parser.add_argument("--expires", type=int, default=3600, help="Expiry in seconds")
    invoice_parser.add_argument("--memo", help="Invoice description")
    
    # Status command
    status_parser = subparsers.add_parser("status", help="Check transaction status")
    status_parser.add_argument("tx_hash", help="Transaction hash")
    
    # Balance command
    balance_parser = subparsers.add_parser("balance", help="Check balance")
    balance_parser.add_argument("address", help="Starknet address")
    balance_parser.add_argument("--token", default="ETH", help="Token to check")
    
    # Config command
    config_parser = subparsers.add_parser("config", help="Show current configuration")
    
    args = parser.parse_args()
    
    # Load config from environment
    RPC_URL = os.environ.get("STARKNET_RPC", "https://rpc.starknet.lava.build:443")
    DEFAULT_ADDRESS = os.environ.get("MINI_PAY_ADDRESS", "")
    DEFAULT_KEY = os.environ.get("MINI_PAY_PRIVATE_KEY", "")
    
    if not args.command:
        parser.print_help()
        return
    
    if args.command == "config":
        print("Starknet Mini-Pay Configuration")
        print("=" * 40)
        print(f"RPC URL: {RPC_URL}")
        print(f"Default Address: {DEFAULT_ADDRESS}")
        print(f"Private Key: {'*' * len(DEFAULT_KEY) if DEFAULT_KEY else 'Not set'}")
        return
    
    if args.command == "send":
        if not args.from_address:
            if DEFAULT_ADDRESS:
                args.from_address = DEFAULT_ADDRESS
            else:
                print("❌ Error: No sender address provided. Set MINI_PAY_ADDRESS or use --from")
                return
        if not args.private_key:
            if DEFAULT_KEY:
                args.private_key = DEFAULT_KEY
            else:
                print("❌ Error: No private key provided. Set MINI_PAY_PRIVATE_KEY or use --key")
                return
        
        pay = MiniPay(rpc_url=RPC_URL)
        
        # Convert amount to wei
        if args.token.upper() == "ETH":
            amount_wei = int(args.amount * 10**18)
        elif args.token.upper() == "STRK":
            amount_wei = int(args.amount * 10**18)
        elif args.token.upper() == "USDC":
            amount_wei = int(args.amount * 10**6)
        else:
            amount_wei = int(args.amount * 10**18)
        
        print(f"📤 Sending {args.amount} {args.token} to {args.address[:10]}...")
        print(f"   Memo: {args.memo or 'None'}")
        
        try:
            tx_hash = pay.send(
                from_address=args.from_address,
                private_key=args.private_key,
                to_address=args.address,
                amount_wei=amount_wei,
                token=args.token.upper(),
                memo=args.memo
            )
            print(f"⏳ Transaction submitted: {tx_hash[:16]}...")
            print("   Waiting for confirmation...")
            
            status = await pay.wait_for_confirmation(tx_hash)
            
            if status == "CONFIRMED":
                print(f"✅ Payment confirmed!")
            else:
                print(f"⚠️ Status: {status}")
                
        except Exception as e:
            print(f"❌ Error: {e}")
    
    elif args.command == "qr":
        qr = QRGenerator()
        try:
            qr.generate(
                address=args.address,
                amount=args.amount,
                memo=args.memo,
                output_file=args.output
            )
            print(f"✅ QR code saved to {args.output}")
            
            # Also print the payment link
            link = PaymentLink()
            url = link.create(args.address, args.amount, args.memo, args.token or "ETH")
            print(f"📱 Payment link: {url}")
            
        except Exception as e:
            print(f"❌ Error: {e}")
    
    elif args.command == "link":
        link = PaymentLink()
        url = link.create(
            address=args.address,
            amount=args.amount,
            memo=args.memo,
            token=args.token
        )
        print(f"🔗 Payment Link:")
        print(f"   {url}")
        
        # Generate QR for the link
        qr = QRGenerator()
        qr_file = f"link_{args.address[:8]}.png"
        qr.generate_link(url, qr_file)
        print(f"📱 QR code saved to {qr_file}")
    
    elif args.command == "parse-link":
        link = PaymentLink()
        data = link.parse(args.url)
        print("📋 Parsed Payment Link:")
        print(f"   Address: {data.get('address', 'N/A')}")
        print(f"   Amount: {data.get('amount', 'N/A')}")
        print(f"   Token: {data.get('token', 'ETH')}")
        print(f"   Memo: {data.get('memo', 'N/A')}")
    
    elif args.command == "invoice":
        invoice = InvoiceManager(rpc_url=RPC_URL)
        
        invoice_data = invoice.create(
            payer_address=args.address,
            amount=args.amount,
            token=args.token.upper(),
            expiry_seconds=args.expires,
            description=args.memo
        )
        
        print(f"📄 Invoice Created:")
        print(f"   ID: {invoice_data['id']}")
        print(f"   Amount: {args.amount} {args.token}")
        print(f"   Expires: {args.expires}s ({args.expires/3600:.1f} hours)")
        print(f"   Address: {args.address}")
        
        # Generate payment link
        link = PaymentLink()
        url = link.create(
            address=args.address,
            amount=args.amount,
            memo=f"Invoice #{invoice_data['id'][:8]}",
            token=args.token
        )
        print(f"   Link: {url}")
    
    elif args.command == "status":
        pay = MiniPay(rpc_url=RPC_URL)
        status = await pay.get_transaction_status(args.tx_hash)
        print(f"Transaction Status: {status}")
    
    elif args.command == "balance":
        pay = MiniPay(rpc_url=RPC_URL)
        balance = await pay.get_balance(args.address, args.token)
        if args.token.upper() == "ETH":
            display_amount = balance / 10**18
        elif args.token.upper() == "USDC":
            display_amount = balance / 10**6
        else:
            display_amount = balance / 10**18
        print(f"Balance: {display_amount:.4f} {args.token}")


if __name__ == "__main__":
    asyncio.run(main())
